@echo off
setlocal
set "setup=%~dp0rustdesk-host=rustdesk.inzoft.com,key=1tReBzyI0r45BmcCQf5XvZsGQldYOklYNjmtHUrI6tI=,-install.exe"
if not exist "%setup%" (
  echo Installer missing. Extract the entire ZIP before running Install.cmd.
  pause
  exit /b 1
)
start "" "%setup%"

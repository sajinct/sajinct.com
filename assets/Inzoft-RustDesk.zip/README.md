# Inzoft RustDesk Windows installer

Prepared: 30 October 2026. Windows x64 client version: **1.5.0**.

## Install

1. Extract the **entire ZIP** to a normal folder on the Windows computer.
2. Double-click **Install.cmd**, or run the included `.exe` directly.
3. Complete the standard RustDesk installation and approve its Windows administrator prompt when requested.
4. Open RustDesk. The ID server and public key should already be configured.
5. Repeat on the other computer you want to connect.

Keep the executable's original long filename until installation is complete. RustDesk reads your server settings from that name. Renaming it to `setup.exe` removes that configuration mechanism. The installed application uses the normal RustDesk name.

## Server settings

| Field | Value |
| --- | --- |
| ID server | `rustdesk.inzoft.com` |
| Public key | `1tReBzyI0r45BmcCQf5XvZsGQldYOklYNjmtHUrI6tI=` |
| API server | Blank |
| Relay server | Automatic; your ID server advertises `rustdesk.inzoft.com:21117` |

The stock installation path imports the hostname and public key. An explicit relay field is not required for a fresh installation because your server advertises the correct relay hostname.

If RustDesk is already installed, finish installation using this package and inspect Settings > Network afterward. In particular, an old explicitly configured Relay Server can survive installation: clear it to use the automatic relay, or set it to `rustdesk.inzoft.com:21117`. Existing MSI installations require a separate migration to the EXE installer; the upstream installer does not support installing its EXE package over MSI. If an existing installation prevents setup, stop and plan its migration rather than deleting its configuration blindly.

This configures the connection service, not an automatic remote-control session. Remote access still needs approval on the destination computer or an unattended-access password configured there. The package does not set or distribute a permanent password, create user accounts, or store SSH/private server keys.

## How it works

This is the **unmodified official RustDesk executable**, renamed using the client's built-in filename configuration parser. The `host=` and `key=` fields are followed by a comma so the installer suffix is not interpreted as part of the key. The `install.exe` suffix opens the standard installation flow. `Install.cmd` only launches that executable.

No RustDesk source was modified or recompiled, and there is no custom unsigned EXE wrapper. Renaming preserves the executable's bytes and its original vendor signature.

## Integrity and validation

- Official asset: `rustdesk-1.5.0-x86_64.exe`.
- Official SHA-256: `8555777215510d83d2d61c9dc984e4fcc838bd7e79f9d18a42585431f5e8bb47`.
- The downloaded asset matched the digest reported by the official GitHub release API.
- Both original and renamed executable passed Windows Authenticode verification, publisher **PURSLANE**.
- The filename configuration and installation suffix were checked against the corresponding RustDesk **1.5.0** source.
- All three public TCP ports, 21115, 21116, and 21117, were reachable through `rustdesk.inzoft.com` when this package was prepared.
- The executable was **not installed or launched on this computer** as part of packaging. A fresh Windows installation and an end-to-end remote session still need validation.
- `verification.json` records the package's executable name, digest, publisher, and embedded public settings.

For a first deployment, install on one Windows test computer and check Settings > Network and the client connection status before distributing to more devices.

## Future updates

This ZIP contains a fixed release, not a downloader that silently changes versions. To rebuild it:

1. Choose an official Windows x64 release and read its release notes.
2. Download the executable from the official release, verify its published digest and Authenticode signature, and inspect that release's filename-configuration support.
3. Rename it to the same `rustdesk-host=...,key=...,-install.exe` filename and replace the bundled executable.
4. Update this README and `verification.json`, then test on a Windows computer.
5. Preserve the domain and public key unless intentionally migrating the server identity.

Changing the public IP behind your existing hostname does not require rebuilding this package. Replacing the server key does require new client settings and a rebuilt package.

## Licence and source

RustDesk is distributed under AGPL-3.0; its licence is included as `RUSTDESK-LICENCE.txt`. This package does not replace or relicense RustDesk.

- [Official 1.5.0 release and original download](https://github.com/rustdesk/rustdesk/releases/tag/1.5.0)
- [Corresponding client source at tag 1.5.0](https://github.com/rustdesk/rustdesk/tree/1.5.0) — includes build instructions and submodule references; use a recursive clone when building.
- [Filename configuration parser](https://github.com/rustdesk/rustdesk/blob/1.5.0/src/custom_server.rs)
- [Windows installation and configuration import](https://github.com/rustdesk/rustdesk/blob/1.5.0/src/platform/windows.rs)
- [Official client configuration guide](https://rustdesk.com/docs/en/self-host/client-configuration/)

For server administration, refer to the separate `RustDesk-server-handover.md` created during server setup.
